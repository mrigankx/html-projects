var quotes=[
'I love you the more in that I believe you had liked me for my own sake and for nothing else.',
'But man is not made for defeat. A man can be destroyed but not defeated.',
'When you reach the end of your rope, tie a knot in it and hang on.',
'There is nothing permanent except change.',
'You cannot shake hands with a clenched fist.',
'Let us sacrifice our today so that our children can have a better tomorrow.',
'Do not mind anything that anyone tells you about anyone else. Judge everyone and everything for yourself.',
'Learning never exhausts the mind.',
'All that we see or seem is but a dream within a dream.',
'Lord, make me an instrument of thy peace. Where there is hatred, let me sow love.',
'Independence is happiness.',
]
var color=[
'blue',
'green',
'yellow',
'red',
'purple',
'violet',
'#69eaef',
'#e8b35f',
'#613d72',
'#6b2b32'
]
function newQuote(){
	var ranQ =Math.floor(Math.random() * (quotes.length));		
	var cn = Math.floor(Math.random() * (color.length));
	document.getElementById('quoteDisplay').innerHTML = quotes[ranQ];
	 document.body.style.background = color[cn];
}
function twt(){
	window.open('https://twitter.com/intent/tweet?text='+ quotes[ranQ]);
}